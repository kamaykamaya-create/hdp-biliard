# HDP GAMES — Biliar 8-Ball · Panduan Build APK Offline

Folder ini adalah proyek Android lengkap. Hasilnya adalah file **APK yang berjalan 100% offline**: aplikasi ini sengaja tidak meminta izin internet.

> Internet hanya dibutuhkan **sekali saat proses build**, untuk mengunduh mesin 3D (Three.js) dan perlengkapan Android. Setelah APK jadi, aplikasi tidak memerlukan kuota sama sekali.

---

## Cara A — Pakai Android Studio di laptop/PC (paling mudah)

1. Unduh dan pasang **Android Studio** (gratis) dari developer.android.com/studio.
2. Ekstrak zip ini, lalu buka Android Studio → **Open** → pilih folder `HDP_Biliar_APK`.
3. Tunggu proses *Gradle Sync* selesai (pertama kali bisa 5–15 menit, butuh internet).
4. Pilih menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Setelah selesai, klik **locate**. File APK ada di:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Kirim file APK itu ke HP (lewat WhatsApp, kabel, atau Google Drive), lalu buka dan pasang.
   Jika muncul peringatan "sumber tidak dikenal", izinkan pemasangan dari aplikasi tersebut.

## Cara B — Tanpa pasang apa pun (build otomatis di GitHub)

1. Buat akun gratis di github.com, lalu buat repository baru (misalnya `hdp-biliar`).
2. Unggah **seluruh isi** folder `HDP_Biliar_APK` ke repository tersebut (termasuk folder `.github`).
3. Buka tab **Actions**. Build akan berjalan otomatis sekitar 5 menit.
4. Setelah ada tanda centang hijau, klik build tersebut, lalu unduh **HDP-Biliar-APK** di bagian *Artifacts*.
5. Ekstrak file yang diunduh, pasang APK-nya di HP.

---

## Isi proyek

| Lokasi | Keterangan |
|---|---|
| `app/src/main/assets/index.html` | Game biliar (semua tampilan & aturan) |
| `app/src/main/assets/three.min.js` | Mesin 3D, **diunduh otomatis saat build** |
| `app/src/main/java/.../MainActivity.java` | Pembungkus aplikasi (layar penuh, tombol kembali, suara) |
| `app/src/main/res/mipmap-*` | Ikon aplikasi |
| `ikon_512.png` | Ikon besar (untuk Play Store bila diperlukan) |
| `.github/workflows/build-apk.yml` | Build otomatis di GitHub (Cara B) |

## Perilaku aplikasi

- Layar penuh, layar tidak mati saat bermain, dan bisa dimainkan dalam posisi tegak maupun miring.
- **Tombol kembali** Android: saat bermain membuka menu jeda, saat di menu utama keluar dari aplikasi.
- Permainan otomatis dijeda ketika aplikasi ditinggalkan, misalnya karena ada telepon masuk.
- Pengaturan (warna meja, format pertandingan, level) tersimpan di HP.
- Nama aplikasi: **HDP Biliar** · ID paket: `id.hdpgames.biliar` · versi 1.0.

## Catatan

- APK hasil Cara A dan B adalah versi *debug*. Versi ini bisa dipasang dan dibagikan langsung ke HP guru lain. Untuk mengunggah ke Play Store diperlukan APK/AAB yang ditandatangani (*signed*), dan langkah ini bisa ditambahkan kemudian.
- Jika ingin mengganti nama aplikasi, ubah `app/src/main/res/values/strings.xml`.
- Jika memperbarui game, cukup ganti `app/src/main/assets/index.html` lalu build ulang. Naikkan juga `versionCode` di `app/build.gradle`.
